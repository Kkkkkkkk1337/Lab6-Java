package llab1;

import java.io.Serializable;

public class RecIntegral implements Serializable
{
    double A, B, H, N;
    
    public RecIntegral(String _A, String _B, String _H) throws MyException {
        try {
            this.A = Double.parseDouble(_A);
            if (this.A < 0.000001 || this.A > 1000000)
                throw new MyException("Число A не удовлетворяет диапазону допустимых значений"); 
        }
        catch(IllegalArgumentException e) { 
            throw new MyException("Неверный ввод нижнего порога"); 
        }
        
        try {
           this.B = Double.parseDouble(_B);
           if (this.B < 0.000001 || this.B > 1000000)
               throw new MyException("Число B не удовлетворяет диапазону допустимых значений"); 
           if (this.A > this.B)
               throw new MyException("Нижний порог интегрирования превышает верхний"); 
        }
        catch(IllegalArgumentException e) {
            throw new MyException("Неверный ввод верхнего порога"); 
        }
        
        try {
            this.H = Double.parseDouble(_H);
            if (this.H < 0.000001 || this.H > 1000000)
                throw new MyException("Число H не удовлетворяет диапазону допустимых значений"); 
        }
        catch(IllegalArgumentException e) { 
            throw new MyException("Неверный ввод шага интегрирования"); 
        }
    }
    
    public RecIntegral() {
        A = 0;
        B = 0;
        H = 0;
    }
}